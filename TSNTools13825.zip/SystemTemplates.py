new_system_template = {
    "systemMapCoord": [0, 0, 0],
    "systemalignment": "USFP",
    "metadata": {},
    "objects": {},
    "sensor_relay": {},
    "terrain": {},
    "traffic": {}
}
